#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMenu>
#include <QAction>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonParseError>
#include <QPainter>
#include <QMouseEvent>
#include <QMessageBox>
#include <QDateTime>
#include <QVector>
#include <qlabel.h>
#include "weatherdata.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    // A
    void contextMenuEvent(QContextMenuEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void getWeatherInfo(QString cityname, bool isUserSearch = false);

    // B：解析数据
    // B：解析 JSON 格式的天气数据
    void parseJson(QByteArray &byteArray);
    // B:解析单天天气数据的辅助函数
    void parseDayData(const QJsonObject& dayObj, Day& day);
    // B:从温度字符串中提取数值的辅助函数
    int extractTemperature(const QString& tempStr);

    // C：更新UI
    // 更新 UI 界面的入口函数
    void updateUI();
    // 更新标题（日期、城市）
    void updateTitleInfo();
    // 更新今日天气详情
    void updateTodayInfo();
    // 更新 6 天预报信息
    void updateForecastInfo();
    // 更新空气质量显示
    void updateAirQuality(int index);


    // C
    bool eventFilter(QObject *watched, QEvent *event) override; //重写绘图事件
    void paintHight();
    void paintLow();
    void drawSimpleCurve(QPainter& painter, const QVector<int>& temperatures, 
                        const QColor& color, bool isHigh);
    void gitcitycode2();

private slots:
    void onReplied(QNetworkReply *reply);
    void Json_city(QNetworkReply *reply);
    void on_btn_search_clicked();
    void on_le_city_returnPressed();

private:
    Ui::MainWindow *ui;
    QMenu *mExitMenu;
    QAction *mExitAct;
    QPoint mOffset;  //鼠标离左上角的距离

    //http请求
    QNetworkAccessManager *mNetAccessManager;
    QNetworkAccessManager *mNetAccessManager1;

    // B
    // 存储天气数据的结构体实例
    Today mToday;
    Day mDay[6];
    // UI 控件列表，用于批量更新界面
    QList<QLabel*> mWeekList;
    QList<QLabel*> mDateList;
    // 存储显示天气类型图标
    QList<QLabel*> mTypeIconList;
    // 存储显示天气类型文本
    QList<QLabel*> mTypeList;
    // 天气污染指数
    QList<QLabel*> mAqiList;
    // 风向
    QList<QLabel*> mFxList;
    // 风力
    QList<QLabel*> mFlList;
    // 天气类型与图标路径的映射，用于更新图标
    QMap<QString, QString> mTypeIconMap;
};
#endif // MAINWINDOW_H
