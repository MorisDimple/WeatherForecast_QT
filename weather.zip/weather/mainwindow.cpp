#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>
#include<QMessageBox>
#include<QJsonDocument>
#include<QJsonObject>
#include<QJsonArray>
#include <QPainter>
#include"weateherTool.h"
#include <QLineEdit>
#include <algorithm>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    setWindowFlag(Qt::FramelessWindowHint);  // 设置窗口无边框
    setFixedSize(width(), height());  // 设置窗口固定大小

    // 构建右键菜单
    mExitMenu = new QMenu(this);  // 创建菜单对象
    mExitAct = new QAction();     // 创建行为对象

    mExitAct->setText("退出");
    mExitAct->setIcon(QIcon(":/res/close.ico"));
    mExitMenu->addAction(mExitAct);  // 将我们的行为添加到菜单里

    connect(mExitAct, &QAction::triggered, this, [=]{
        qApp->exit(0);
    });

//控件添加到控件数组
    //添加日期
    mWeekList<<ui->lb_week0<<ui->lb_week1<<ui->lb_week2<<ui->lb_week3<<ui->lb_week4<<ui->lb_week5;
    //添加星期
    mDateList<<ui->lb_date0<<ui->lb_date1<<ui->lb_date2<<ui->lb_date3<<ui->lb_date4<<ui->lb_date5;
    //添加天气图标
    mTypeIconList<<ui->lb_con0<<ui->lb_con1<<ui->lb_con2<<ui->lb_con3<<ui->lb_con4<<ui->lb_con5;
    //添加天气情况
    mTypeList<<ui->lb_type0<<ui->lb_type1<<ui->lb_type2<<ui->lb_type3<<ui->lb_type4<<ui->lb_type5;
    //添加天气污染情况
    mAqiList<<ui->lb_Aqi0<<ui->lb_Aqi1<<ui->lb_Aqi2<<ui->lb_Aqi3<<ui->lb_Aqi4<<ui->lb_Aqi5;
    //添加风向情况
    mFxList<<ui->lb_fx0<<ui->lb_fx1<<ui->lb_fx2<<ui->lb_fx3<<ui->lb_fx4<<ui->lb_fx5;
    //添加风力情况
    mFlList<<ui->lb_fl0<<ui->lb_fl1<<ui->lb_fl2<<ui->lb_fl3<<ui->lb_fl4<<ui->lb_fl5;

    mTypeIconMap.insert("晴", ":/weatherImages/type/Qing.png");
    mTypeIconMap.insert("多云", ":/weatherImages/type/DuoYun.png");
    mTypeIconMap.insert("阴", ":/weatherImages/type/Yin.png");
    mTypeIconMap.insert("雨", ":/weatherImages/type/Yu.png");
    mTypeIconMap.insert("雪", ":/weatherImages/type/Xue.png");
    mTypeIconMap.insert("沙尘暴", ":/weatherImages/type/ShaChenBao.png");

    mTypeIconMap.insert("雷阵雨", ":/weatherImages/type/LeiZhenYu.png");
    mTypeIconMap.insert("大雨", ":/weatherImages/type/DaYu.png");
    mTypeIconMap.insert("小雨", ":/weatherImages/type/XiaoYu.png");
    mTypeIconMap.insert("中雨", ":/weatherImages/type/ZhongYu.png");
    mTypeIconMap.insert("阵雨", ":/weatherImages/type/ZhenYu.png");
    mTypeIconMap.insert("暴雨", ":/weatherImages/type/BaoYu.png");
    mTypeIconMap.insert("大暴雨", ":/weatherImages/type/DaBaoYu.png");
    mTypeIconMap.insert("大到暴雨",":/weatherImages/type/DaDaoBaoYu.png");
    mTypeIconMap.insert("暴雨到大暴雨",":/weatherImages/type/BaoYuDaoDaBaoYu.png");
    mTypeIconMap.insert("大暴雨到大暴雨",":/weatherImages/type/DaBaoYuDaoDaBaoYu.png");

    mTypeIconMap.insert("暴雪",":/weatherImages/type/BaoXue.png");
    mTypeIconMap.insert("大到暴雪",":/weatherImages/type/DaDaoBaoXue.png");
    mTypeIconMap.insert("大雪", ":/weatherImages/type/DaXue.png");
    mTypeIconMap.insert("小雪", ":/weatherImages/type/XiaoXue.png");
    mTypeIconMap.insert("中雪", ":/weatherImages/type/ZhongXue.png");


    mTypeIconMap.insert("雨夹雪", ":/weatherImages/type/YuJiaXue.png");
    mTypeIconMap.insert("霾", ":/weatherImages/type/Mai.png");
    mTypeIconMap.insert("扬沙", ":/weatherImages/type/YangSha.png");
    mTypeIconMap.insert("沙尘暴", ":/weatherImages/type/ShaChenBao.png");
    mTypeIconMap.insert("特大暴雨", ":/weatherImages/type/TeDaBaoYu.png");
    mTypeIconMap.insert("乌", ":/weatherImages/type/Wu.png");
    mTypeIconMap.insert("小到中雨", ":/weatherImages/type/XiaoDaoZhongYu.png");
    mTypeIconMap.insert("小到中雪", ":/weatherImages/type/XiaoDaoZhongXue.png");
    mTypeIconMap.insert("雨夹雪", ":/weatherImages/type/YuJiaXue.png");
    mTypeIconMap.insert("阵雪", ":/weatherImages/type/ZhenXue.png");

    // 定位请求网络
    mNetAccessManager =new QNetworkAccessManager(this);
    connect(mNetAccessManager,&QNetworkAccessManager::finished,this,&MainWindow::Json_city);
    gitcitycode2();


    //3.请求网络
    mNetAccessManager1 =new QNetworkAccessManager(this);
    connect(mNetAccessManager1,&QNetworkAccessManager::finished,this,&MainWindow::onReplied);

    //城市的天气代码
    //getWeatherInfo("101010100");



    //安装事件过滤器
    ui->lb_HigtCurve->installEventFilter(this);
    ui->lb_LowCurve->installEventFilter(this);
    ui->le_city->setPlaceholderText( "请输入城市名称:" );

}

MainWindow::~MainWindow()
{
    delete ui;
}


// 弹出右键菜单
void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    mExitMenu->exec(QCursor::pos());  // 传送鼠标位置
}

//处理鼠标点击事件
void MainWindow::mousePressEvent(QMouseEvent *event)
{
    mOffset = event->globalPos() - this->pos();
}

//处理鼠标移动事件
void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    this->move(event->globalPos() - mOffset);
}


//通过输入一个城市的代码获取这个城市的天气
void MainWindow::getWeatherInfo(QString cityname, bool isUserSearch)
{
     QString citycode=WeatherTool::getcitycode(cityname);
    if(citycode.isEmpty())
    {
        if (isUserSearch) {
            QMessageBox msgBox(this);
            msgBox.setText(QStringLiteral("您输入的城市不存在，请检查后重试！"));
            msgBox.setWindowTitle(QStringLiteral("天气"));
            msgBox.setIcon(QMessageBox::Warning);
            msgBox.setStyleSheet("QLabel{min-width:250px; min-height:50px; font-size:14px; color: black;}");
            msgBox.exec();
        }
        return;
    }
        QUrl url("http://t.weather.itboy.net/api/weather/city/" + citycode); //这个网址返回的数据时json格式
        mNetAccessManager1->get(QNetworkRequest(url)); //get请求完成就会是finished，上面的槽函数onReplied就会被调用

}

// B: 解析从天气API获取的JSON数据
// 接收原始的JSON数据 QByteArray，并将其解析成程序内部定义的 Today 和 Day 对象
void MainWindow::parseJson(QByteArray &byteArray)
{
    // 创建一个QJsonParseError对象，用于存储JSON解析过程中可能出现的错误信息
    QJsonParseError error;
    // 将字节数组解析为JSON文档，同时传入error对象以捕获可能的错误
    QJsonDocument doc = QJsonDocument::fromJson(byteArray, &error);
    if(error.error != QJsonParseError::NoError) {
        return;
    }
    // 获取JSON文档的根对象
    QJsonObject rootObj = doc.object();
    // 从根对象中提取名为"data"的子对象
    QJsonObject dataObj = rootObj.value("data").toObject();
    
    // 解析城市和日期信息
    // 从根对象的"cityInfo"子对象中获取城市名称，并赋值给mToday的city成员
    mToday.city = rootObj.value("cityInfo").toObject().value("city").toString();
    // 从根对象中获取日期信息，并赋值给mToday的date成员
    mToday.date = rootObj.value("date").toString();
    
    // 解析今天的基本信息
    mToday.wendu = dataObj.value("wendu").toString();
    mToday.ganmao = dataObj.value("ganmao").toString();
    mToday.shidu = dataObj.value("shidu").toString();
    mToday.pm25 = dataObj.value("pm25").toInt();
    mToday.quality = dataObj.value("quality").toString();
    
    // 解析天气数据（昨天 + 未来5天）
    // 从"data"对象中获取名为"forecast"的JSON数组
    QJsonArray forecastArr = dataObj.value("forecast").toArray();
    
    // 解析昨天的数据
    QJsonObject yesterdayObj = dataObj.value("yesterday").toObject();
    // 调用parseDayData函数解析昨天的天气数据，并将结果存储在mDay[0]中
    parseDayData(yesterdayObj, mDay[0]);
    
    // 解析未来5天的数据
    // 遍历"forecast"数组，最多处理前5个元素
    for(int i = 0; i < 5 && i < forecastArr.size(); i++) {
        // 调用parseDayData函数解析未来某天的天气数据，并将结果存储在mDay[i+1]中
        parseDayData(forecastArr[i].toObject(), mDay[i+1]);
    }

    // 设置今天的数据（使用明天的数据，因为API中今天的数据在forecast[0]）
    // 检查"forecast"数组是否至少有一个元素
    if(forecastArr.size() > 0) {
        mToday.type = mDay[1].type;
        mToday.high = mDay[1].high;
        mToday.low = mDay[1].low;
        mToday.fx = mDay[1].fx;
        mToday.fl = mDay[1].fl;
    }

    // 调用updateUI函数更新UI界面
    updateUI();
}


// B：解析单天天气数据的辅助函数
void MainWindow::parseDayData(const QJsonObject& dayObj, Day& day)
{

    day.week = dayObj.value("week").toString();// 星期
    day.date = dayObj.value("ymd").toString();// 日期
    day.type = dayObj.value("type").toString();// 天气类型
    day.aqi = dayObj.value("aqi").toDouble();// 空气质量
    day.fx = dayObj.value("fx").toString();// 风向
    day.fl = dayObj.value("fl").toString();//风力
    
    // 解析温度数据
    // 从JSON对象中获取最高温度信息
    QString highStr = dayObj.value("high").toString();
    // 从JSON对象中获取最低温度信息
    QString lowStr = dayObj.value("low").toString();

    // 提取温度数值
    day.high = extractTemperature(highStr);
    day.low = extractTemperature(lowStr);
}

// B: 提取温度数值的辅助函数
int MainWindow::extractTemperature(const QString& tempStr)
{
    // 使用空格分割温度字符串
    QStringList parts = tempStr.split(" ");
    // 检查分割后的字符串列表是否至少有两个元素
    if(parts.size() >= 2) {
        // 获取温度值部分
        QString tempValue = parts[1];
        // 去掉温度值末尾的单位符号（如"°"），并转换为整数后返回
        return tempValue.left(tempValue.length() - 1).toInt();
    }
    // 如果分割后的字符串列表元素不足，返回0
    return 0;
}

// B:更新UI
void MainWindow::updateUI()
{
    // 更新标题信息
    updateTitleInfo();
    
    // 更新左侧今天的信息
    updateTodayInfo();
    
    // 更新右侧6天预报信息
    updateForecastInfo();
    
    // 更新温度曲线
    ui->lb_HigtCurve->update();
    ui->lb_LowCurve->update();
}

// B：更新标题信息
void MainWindow::updateTitleInfo()
{
    QString formattedDate = QDateTime::fromString(mToday.date, "yyyyMMdd").toString("yyyy/MM/dd");
    ui->lb_date->setText(formattedDate + " " + mDay[1].week);
    ui->lb_city->setText(mToday.city);
}

// B：更新今天的信息
void MainWindow::updateTodayInfo()
{
    ui->lb_TypeIcon->setPixmap(mTypeIconMap.value(mToday.type, ":/weatherImages/type/DuoYun.png"));
    ui->lb_temperature->setText(mToday.wendu);
    ui->lb_type->setText(mToday.type);
    ui->lb_LowHigh->setText(QString("%1°~%2°").arg(mToday.low).arg(mToday.high));
    ui->lb_ganmao->setText("感冒指数：" + mToday.ganmao);
    ui->lb_Windfx->setText(mToday.fx);
    ui->lb_Winfl->setText(mToday.fl);
    ui->lb_PM25->setText(QString::number(mToday.pm25));
    ui->lb_shidu->setText(mToday.shidu);
    ui->lb_quality->setText(mToday.quality);
}

// B：更新6天预报信息
void MainWindow::updateForecastInfo()
{
    // 星期标签的特殊处理：昨天、今天、明天
    mWeekList[0]->setText("昨天");
    mWeekList[1]->setText("今天");
    mWeekList[2]->setText("明天");

    for(int i = 0; i < 6; i++) {
        // 对于后三天，显示具体的星期
        if (i > 2) {
            mWeekList[i]->setText("周" + mDay[i].week.right(1)); // 数据是"星期六",取右边第一位
        }

        // 更新日期 ,数据是"2023-07-28"
        QStringList dateParts = mDay[i].date.split("-");
        if(dateParts.size() >= 3) {
            mDateList[i]->setText(QString("%1/%2").arg(dateParts[1]).arg(dateParts[2]));
        }

        // 更新天气类型和图标
        mTypeList[i]->setText(mDay[i].type);
        mTypeIconList[i]->setPixmap(mTypeIconMap.value(mDay[i].type, ":/weatherImages/type/DuoYun.png"));

        // 更新空气质量
        updateAirQuality(i);

        // 更新风向和风力
        mFxList[i]->setText(mDay[i].fx);
        mFlList[i]->setText(mDay[i].fl);
    }
}

// B：更新空气质量显示
void MainWindow::updateAirQuality(int index)
{
    int aqi = mDay[index].aqi;
    QString quality;
    QString color;
    
    if(aqi <= 50) {
        quality = "优";
        color = "background-color: rgb(121, 184, 0);";
    } else if(aqi <= 100) {
        quality = "良";
        color = "background-color: rgb(255, 187, 23);";
    } else if(aqi <= 150) {
        quality = "轻度";
        color = "background-color: rgb(255, 87, 97);";
    } else if(aqi <= 200) {
        quality = "中度";
        color = "background-color: rgb(235, 17, 27);";
    } else if(aqi <= 250) {
        quality = "重度";
        color = "background-color: rgb(170, 0, 0);";
    } else {
        quality = "严重";
        color = "background-color: rgb(110, 0, 0);";
    }
    
    mAqiList[index]->setText(quality);
    mAqiList[index]->setStyleSheet(color);
}

//注意这里要在更新UI函数这里调用Upadate函数，不然就会一直显示都是温度曲线0
//因为eventFilter会最先调用，请求服务器那些语句都还没执行，所以不会有数据
//在更新UI函数中，在调用一次eventFilter函数就会有数据，此时请求数据的那些函数已经被执行


bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if(event->type() == QEvent::Paint)
    {
        if(watched == ui->lb_HigtCurve)
        {
            paintHight();  // 改回原来的函数名
        }

        if(watched == ui->lb_LowCurve)
        {
            paintLow();
        }
    }
    return QWidget::eventFilter(watched,event);
}

void MainWindow::paintHight()
{
    QPainter painter(ui->lb_HigtCurve);
    painter.setRenderHint(QPainter::Antialiasing, true);
    
    // 获取高温数据
    QVector<int> temperatures;
    for (int i = 0; i < 6; i++) {
        temperatures.append(mDay[i].high);
    }
    
    // 简化的绘制方式
    drawSimpleCurve(painter, temperatures, QColor(250, 170, 0), true);
}

void MainWindow::paintLow()
{
    QPainter painter(ui->lb_LowCurve);
    painter.setRenderHint(QPainter::Antialiasing, true);
    
    // 获取低温数据
    QVector<int> temperatures;
    for (int i = 0; i < 6; i++) {
        temperatures.append(mDay[i].low);
    }
    
    // 简化的绘制方式
    drawSimpleCurve(painter, temperatures, QColor(0, 255, 255), false);
}

// 新增：简化的温度曲线绘制函数
void MainWindow::drawSimpleCurve(QPainter& painter, const QVector<int>& temperatures, 
                                const QColor& color, bool isHigh)
{
    if(temperatures.isEmpty()) return;
    
    int width = ui->lb_HigtCurve->width();
    int height = ui->lb_HigtCurve->height();
    
    int minTemp = *std::min_element(temperatures.begin(), temperatures.end());
    int maxTemp = *std::max_element(temperatures.begin(), temperatures.end());
    // 增加一个缓冲值，使曲线不会紧贴边缘
    int buffer = 5; 
    minTemp -= buffer;
    maxTemp += buffer;

    int tempRange = maxTemp - minTemp;
    if(tempRange <= 0) tempRange = 1; // 避免除零或负数范围
    
    // 设置画笔
    QPen pen(color, 3); // 增加线条宽度
    painter.setPen(pen);
    painter.setFont(QFont("Microsoft YaHei", 9)); // 调整字体大小
    
    // 绘制温度点和连线
    QVector<QPoint> points;

    int horizontalMargin = 50; // 进一步增加左右边距，为文本提供更多空间
    int effectiveWidth = width - (2 * horizontalMargin);
    if (effectiveWidth <= 0) effectiveWidth = 1;

    for(int i = 0; i < temperatures.size(); i++) {
        // Calculate X coordinate, considering margin
        int x;
        if (temperatures.size() == 1) {
            x = width / 2; // If only one point, place in center
        } else {
            x = horizontalMargin + (i * effectiveWidth) / (temperatures.size() - 1);
        }

        // Calculate Y coordinate, map temperature to plotting area
        int y = height - ((temperatures[i] - minTemp) * height / tempRange);
        
        // Ensure Y coordinate is within valid range
        if (y < 0) y = 0;
        if (y > height) y = height;

        points.append(QPoint(x, y));
        
        // Draw temperature point
        painter.setBrush(color); // Set fill color
        painter.drawEllipse(QPoint(x, y), 4, 4); // Increase point size
        
        // Draw temperature text
        QString tempText = QString::number(temperatures[i]) + "°";
        int textWidth = painter.fontMetrics().horizontalAdvance(tempText);

        int textX = x - textWidth / 2; // Center text horizontally initially

        // Boundary check for text X position, considering the horizontal margin
        if (textX < horizontalMargin) {
            textX = horizontalMargin; // Align to the left margin
        } else if (textX + textWidth > width - horizontalMargin) {
            textX = width - horizontalMargin - textWidth; // Align to the right margin
        }

        painter.drawText(QPoint(textX, y - 15), tempText); // Adjust text Y offset
    }
    
    // Draw lines
    painter.setBrush(Qt::NoBrush); // No fill for lines
    for(int i = 0; i < points.size() - 1; i++) {
        painter.drawLine(points[i], points[i + 1]);
    }
}

//http发送请求定位
void MainWindow::gitcitycode2()
{
    QNetworkRequest request;
    request.setUrl(QUrl("https://api.map.baidu.com/location/ip?ak=Y83fVkydCr7fNFcAem8iMU8zDtPOGrdK&coor=bd09ll"));
    mNetAccessManager->get(request);
    qDebug() << "发送了定位请求";
}


// B:检查网络请求是否成功（HTTP状态码和网络错误），如果成功，则读取并解析返回的JSON数据，然后调用 parseJson 进行详细解析
// 当 QNetworkAccessManager 完成一个天气数据请求时，它会发出 finished 信号，连接到这个槽函数。
void MainWindow::onReplied(QNetworkReply *reply)
{
    qDebug()<<"onReplied success";
    int status_code=reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();

    // 检查网络请求是否出错或HTTP状态码不是200
    if(reply->error()!=QNetworkReply::NoError||status_code!=200)
    {
        qDebug()<<reply->errorString().toLatin1().data();
        QMessageBox::warning(this,"天气","请求数据失败",QMessageBox::Ok);
    }
    else
    {
        // 读取所有返回的数据
        QByteArray reply_data = reply->readAll();
        // 将数据转换为UTF-8编码的QByteArray，以便JSON解析
        QByteArray byteArray = QString(reply_data).toUtf8();
        // 调用parseJson函数解析获取到的JSON数据
        parseJson(byteArray);
    }
}

void MainWindow::Json_city(QNetworkReply *reply)
{
     qDebug()<<"Json_city success";
    QString locat_city;
    QString all = reply->readAll();
    qDebug()<<all;
    //unicode 转化为汉字
    QString filename = all;
    do
    {
        int idx = filename.indexOf("\\u");
        QString strHex = filename.mid(idx, 6);
        strHex = strHex.replace("\\u", QString());
        int nHex = strHex.toInt(0, 16);
        filename.replace(idx, 6, QChar(nHex));
    } while (filename.indexOf("\\u") != -1);
        //json解析过程
    QJsonDocument  Document;
    QJsonParseError json_error;
    QJsonDocument json_recv = QJsonDocument::fromJson(all.toUtf8(),&json_error);//解析json对象
    QJsonObject object = json_recv.object();
    if(object.contains("content"))
    {
        QJsonValue value = object.value("content");
        if(value.isObject())
        {
            QJsonObject object_1 = value.toObject();
            if(object_1.contains("address_detail"))
            {
                QJsonValue value_1 = object_1.value("address_detail");
                if(value_1.isObject())
                {
                    QJsonObject object_2 = value_1.toObject();
                    locat_city =object_2.value("city").toString();
                    qDebug()<<locat_city;
                }
            }
        }
    }
    getWeatherInfo(locat_city, false); // 定位城市时不弹窗
}


//搜索按钮点击搜索
void MainWindow::on_btn_search_clicked()
{
    QString cityname = ui->le_city->text();
    getWeatherInfo(cityname, true); // 用户主动搜索时弹窗
}

//输入框回车搜索
void MainWindow::on_le_city_returnPressed()
{
    QString cityname = ui->le_city->text();
    getWeatherInfo(cityname, true); // 用户主动搜索时弹窗
}




