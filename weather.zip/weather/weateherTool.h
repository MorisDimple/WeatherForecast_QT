#ifndef WEATEHERTOOL_H
#define WEATEHERTOOL_H

#include<QMap>
#include<QFile>
#include<QString>
#include<QJsonArray>
#include<QJsonDocument>
#include<QJsonParseError>
#include<QJsonValue>
#include<QDebug>

class WeatherTool
{
private:
    static QMap<QString,QString> mcityMap;
    static bool isInitialized;

    // 初始化城市编码映射
    static bool InitcityMap()
    {
        if (isInitialized) {
            return true;
        }

        QFile file(":/citycode.json");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        {
            qDebug() << "Failed to open citycode.json file";
            return false;
        }

        QByteArray json = file.readAll();
        file.close();

        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(json, &error);
        if (error.error != QJsonParseError::NoError || !doc.isArray())
        {
            qDebug() << "Failed to parse citycode.json:" << error.errorString();
            return false;
        }

        QJsonArray cityArr = doc.array();
        for (const QJsonValue &cityValue : cityArr)
        {
            QJsonObject cityObj = cityValue.toObject();
            QString city = cityObj.value("city_name").toString();
            QString code = cityObj.value("city_code").toString();
            
            if (!code.isEmpty())
            {
                mcityMap.insert(city, code);
            }
        }

        isInitialized = true;
        return true;
    }

    // 尝试不同的城市名称格式
    static QString tryCityNameFormats(const QString &cityname)
    {
        QStringList formats = {
            cityname,
            cityname + "市",
            cityname + "区",
            cityname + "县"
        };

        for (const QString &format : formats)
        {
            auto it = mcityMap.find(format);
            if (it != mcityMap.end())
            {
                return it.value();
            }
        }

        return "";
    }

public:
    // 获取城市编码
    static QString getcitycode(const QString &cityname)
    {
        if (cityname.isEmpty())
        {
            qDebug() << "City name is empty";
            return "";
        }

        if (!InitcityMap())
        {
            qDebug() << "Failed to initialize city map";
            return "";
        }

        QString code = tryCityNameFormats(cityname);
        if (code.isEmpty())
        {
            qDebug() << "City code not found for:" << cityname;
        }
        return code;
    }
};

QMap<QString,QString> WeatherTool::mcityMap = {};
bool WeatherTool::isInitialized = false;

#endif // WEATEHERTOOL_H
